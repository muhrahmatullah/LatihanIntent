package com.example.rahmat.latihanintent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
        String nama = intent.getStringExtra("user");
        TextView tvnama = (TextView) findViewById(R.id.nama);
        tvnama.setText(nama);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        else if(id == R.id.action_exit){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    //Intent untuk menelpon
    public void tesCall(View view) {
        EditText edCall = (EditText) findViewById(R.id.callnum);

        String uri = "tel:" + edCall.getText().toString().trim();
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse(uri));
        startActivity(intent);
    }
    //Intent untuk kembali ke LoginActiviy.java
    public void logout(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    //Intent untuk mengirim email
    public void sendEmail(View view) {
    EditText email = (EditText) findViewById(R.id.email);
    Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email.getText().toString()));
    startActivity(Intent.createChooser(emailIntent,"Chooser Title"));
    }
}
